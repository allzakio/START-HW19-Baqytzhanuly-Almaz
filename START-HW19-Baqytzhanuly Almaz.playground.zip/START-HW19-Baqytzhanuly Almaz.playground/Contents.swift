import UIKit

func getData(urlRequest: String, with timeout: TimeInterval) {
    guard let url = URL(string: urlRequest) else { return }
    let configuration = URLSessionConfiguration.default
    configuration.allowsCellularAccess = true
    configuration.waitsForConnectivity = true
    configuration.timeoutIntervalForRequest = timeout
    let urlSession = URLSession(configuration: configuration)
    urlSession.dataTask(with: url) { data, response, error in
        if error != nil {
            print("Error in request")
        } else if let response = response as? HTTPURLResponse, response.statusCode == 200 {
            guard let data = data else { return }
            let dataAsString = String(data: data, encoding: .utf8)
            print("Response status code: \(response.statusCode)")
            print("JSON data: \(String(describing: dataAsString))")
        }
    }.resume()
}

getData(urlRequest: "http://api.alquran.cloud/v1/surah", with: 5)
